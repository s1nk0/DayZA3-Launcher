<html>
<head>
	<title>Pwnoz0r :: Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
</head>

<!-- BODY -->
<body class="fadeDown">

<!-- NAVIGATION -->
<div class="well">
	<ul class="nav nav-tabs">
		<li class="active"><a href="#home" data-toggle="tab"><i class="icon-home"></i> Home</a></li>
		<li><a href="#portfolio" data-toggle="tab"><i class="icon-briefcase"></i> Portfolio</a></li>
		<li><a href="#contact" data-toggle="tab"><i class="icon-user"></i> Contact</a></li>
		<li><a href="#livestream" data-toggle="tab"><i class="icon-play"></i> Livestream</a></li>
		<li><a href="#tutorials" data-toggle="tab"><i class="icon-wrench"></i> Tutorials</a></li>
<!--	<li><a href="#donations" data-toggle="tab"><i class="icon-gift"></i> Donations</a></li>			-->
	</ul>

<div id="myTabContent" class="tab-content">
<div class="tab-pane active in" id="home">

<!-- HOME -->
	<div class="span8">
		<h1>Welcome to my website!</h1>
		<p>This is the official website of "Pwnoz0r". I have had home pages in the past, but this one is the new sleek (up to date)
			version. If you have any questions/comments/concerns about anything involving myself please do so by clicking the <b>contact</b> tab.</p>
	<span class="badge badge-success">Posted: 3/17/13 5:00PM (EST)</span>
	</div>

</div>

<!-- PORTFOLIO -->
<div class="tab-pane fade" id="portfolio">    
	<ul class="thumbnails">
	<li class="span4">
		<div class="thumbnail">
			<img src="/img/dayz_logo.png" alt="DayZMod">
				<div class="caption">
					<h3>DayZMod Developer</h3>
					<p>A community developer for the popular mod "DayZ".</p>
					<p align="center"><a href="http://dayzmod.com/" target="_blank" class="btn btn-primary btn-block">Open</a></p>
				</div>
		</div>
	</li>

	<li class="span4">
		<div class="thumbnail">
			<img src="/img/github_logo.png" alt="DayZMod Private Server">
				<div class="caption">
					<h3>DayZ Private Server</h3>
					<p>Allows <i>anyone</i> to host a private server for DayZ.</p>
					<p align="center"><a href="https://github.com/Pwnoz0r/DayZ-Private-Server" target="_blank" class="btn btn-primary btn-block">Open</a></p>
				</div>
		</div>
	</li>
	</ul>
</div>

<!-- CONTACT -->
<div class="tab-pane fade" id="contact">
	<div class="span6">
		<form name="form" method="POST" action="form_post.php">
		<div class="controls controls-row">
			<input id="name" name="name" type="text" class="span3" placeholder="Name"> 
			<input id="email" name="email" type="email" class="span3" placeholder="Email">
		</div>
		<div class="controls">
			<textarea id="message" name="message" class="span6" placeholder="Message" rows="5"></textarea>
		</div>
      	<div class="controls">
			<button id="contact-submit" type="submit" class="btn btn-primary input-medium pull-right">Send</button>
		</div>
		</form>
	</div>
</div>

<!-- LIVESTREAM -->
<div class="tab-pane fade" id="livestream">
	<div class="span12">
		<h1>Livestream</h1>
		<object type="application/x-shockwave-flash" height="597" width="930" id="live_embed_player_flash" data="http://www.twitch.tv/widgets/live_embed_player.swf?channel=pwnoz0r" bgcolor="#000000"><param name="allowFullScreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="allowNetworking" value="all" /><param name="movie" value="http://www.twitch.tv/widgets/live_embed_player.swf" /><param name="flashvars" value="hostname=www.twitch.tv&channel=pwnoz0r&auto_play=true&start_volume=0" /></object>
	</div>
	<div class="span8">
		<h1>Chat</h1>
		<iframe frameborder="0" scrolling="no" id="chat_embed" src="http://twitch.tv/chat/embed?channel=pwnoz0r&amp;popout_chat=true" height="597" width="350"></iframe>      
	</div>
</div>

<!-- TUTORIALS -->
<div class="tab-pane fade" id="tutorials">
      <div class="span8">
		<h3>Visual Basic</h3>
		<p>Video Number 1</p>
		<p>Video Number 2</p>
		<p>Video Number 3</p>
		<p>Video Number 4</p>
		<p>Video Number 5</p>
		<p>Video Number 6</p>
		<p>Video Number 7</p>
		<p>Video Number 8</p>
		<p>Video Number 9</p>
		<p>Video Number 10</p>
      </div>
</div>

<!-- DONATIONS
<div class="tab-pane fade" id="donations">
      <div class="span8">
          <h1>Donations</h1>
          <embed allowscriptaccess="never" height="224" src="http://pitchinbox.com/widget/widget.swf?id=2836361565" type="application/x-shockwave-flash" width="320" wmode="transparent">
      </div>
</div>
 -->

</div>
<hr>

<!-- FOOTER -->
<div class="footer" style="padding-left: 20px;">
<footer>Pwnoz0r &copy; 2013</footer>
</div>

<!-- SCRIPTS AND RESOURCES --> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="http://twitter.github.com/bootstrap/assets/js/google-code-prettify/prettify.js"></script>
<script src="js/bootstrapSwitch.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap-alert.js"></script>
<script src="js/bootstrap-modal.js"></script>
<script src="js/bootstrap-dropdown.js"></script>
<script src="js/bootstrap-scrollspy.js"></script>
<script src="js/bootstrap-tab.js"></script>
<script src="js/bootstrap-tooltip.js"></script>
<script src="js/bootstrap-popover.js"></script>
<script src="js/bootstrap-button.js"></script>
<script src="js/bootstrap-collapse.js"></script>
<script src="js/bootstrap-carousel.js"></script>
<script src="js/bootstrap-typeahead.js"></script>
<script type="text/javascript" src="js/kCode.js"></script>
<script type="text/javascript" src="js/kCodeAV.js"></script>

<audio src="res/toulouse.mp3" id="mp3" preload="auto"></audio>

</body>
</html>