<?php
	$name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	$ipaddress = $_SERVER["REMOTE_ADDR"];
	$formcontent="Name: $name \nEmail: $email \nIP: $ipaddress \n\nMessage: $message";
	$recipient = "contact@pwnoz0r.com";
	$subject = "Contact Form";
	$mailheader = "From: $email \r\n";	

	if (!strlen(trim($_POST['name'])) OR !strlen(trim($_POST['email'])) OR !strlen(trim($_POST['message']))) {
		echo "
<head>
	<title>Invalid Information</title>
	<meta http-equiv='refresh' content='5; url=index.php''>
	<link href='css/main.css' rel='stylesheet'>
	<link href='css/bootstrap.min.css' rel='stylesheet' media='screen'>
</head>
	<div class='fadeDown'>
		<div class='span8'>
			<h1>Invalid Information</h1>
			<p>Please fix the mistakes you made and try again. If you are not redirected in 5 seconds, click <a href='index.php'>here</a>.</p>
		</div>
	</div>";
	}else{
		mail($recipient, $subject, $formcontent, $mailheader) or die("Error, the message was not sent. Please try again!");
		echo "
<head>
	<title>Form Sent!</title>
	<meta http-equiv='refresh' content='5; url=index.php''>
	<link href='css/main.css' rel='stylesheet'>
	<link href='css/bootstrap.min.css' rel='stylesheet' media='screen'>
</head>
	<div class='fadeDown'>
		<div class='span8'>
			<h1>Thank you!</h1>
			<p>You are now being redirected back to the homepage. If you are not redirected in 5 seconds, click <a href='index.php'>here</a>.</p>
		</div>
	</div>";
	}
?>